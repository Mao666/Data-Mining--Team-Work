
# coding: utf-8

# In[ ]:


import numpy as np#linear algebra
import pandas as pd # data processing,CSV file I/O

from subprocess import check_output
from sklearn.model_selection import train_test_split


#load data
train_data = pd.read_csv("E:/Data Mining/GroupCoursework/Data/train_new1.csv")
test_data = pd.read_csv("E:/Data Mining/GroupCoursework/Data/test_new.csv")

# target= train_data['count']
# train_data, test_data, train_target, test_target = train_test_split(train_data, target, test_size=0.2, random_state=0)


#train_data = data.iloc[:9000,:14]
#test_data = data.iloc[9000::14]


cols = [0,14,15,16,17,18,19,20,21,22,23]
test_data.drop(test_data.columns[cols],axis=1,inplace=True)

for col in test_data.columns:
    t1 = test_data[col].dtype
    t2 = train_data[col].dtype
    if t1 != t2:
        print(col,t1,t2)

c = ['season','holiday', 'workingday', 'weather', 'temp', 'atemp', 'humidity','windspeed','hour','year','weekday','month','day']
for cols in c:
    #tmp_col = test_data[cols].astype(pd.np.float64)
    tmp_col = test_data[cols].astype(pd.np.int64)
    tmp_col = pd.DataFrame({cols: tmp_col})
    del test_data[cols]
    test_data = pd.concat((test_data, tmp_col), axis=1)   
        
#one-hot coding
for cols in train_data.columns:
    if train_data[cols].dtype == np.object:
        train_data = pd.concat((train_data, pd.get_dummies(train_data[cols], prefix=cols)), axis=1)
        del train_data[cols]

for cols in test_data.columns:
    if test_data[cols].dtype == np.object:
        test_data = pd.concat((test_data, pd.get_dummies(test_data[cols], prefix=cols)), axis=1)
        del test_data[cols] 
        
train_y = train_data['count']# train_targat
#特征对齐
col_train = train_data.columns
col_test = test_data.columns
for index in col_train:
    if index in col_test:
        pass
    else:
        del train_data[index]

col_train = train_data.columns
col_test = test_data.columns
for index in col_test:
    if index in col_train:
        pass
    else:
        del test_data[index]  
          
        
#RF slecte important features
from sklearn.ensemble import RandomForestRegressor
etr = RandomForestRegressor()
train_x = train_data
etr.fit(train_x, train_y)
#print(etr.feature_importances_)

imp = etr.feature_importances_
imp = pd.DataFrame({'feature': train_x.columns, 'score': imp})
print(imp.sort_values(['score'], ascending=[0]))  # order by importance
imp = imp.sort_values(['score'], ascending=[0])
imp.to_csv('feature_importances.csv', index=False)

#bivariate analysis saleprice/grlivarea 
imp[['feature','score']].plot(kind='bar', stacked=True)   

#select the Top 20 features
select_feature=imp['feature'][:20]
xtrain_feature=train_x.loc[:,select_feature]

rf_select_model=etr.fit(xtrain_feature,train_y)

#write submission

subm = pd.read_csv("E:/Data Mining/GroupCoursework/Data/sampleSubmission.csv")
xtest_feature=test_data.loc[:,select_feature]
subm.iloc[:,1] = np.array(rf_select_model.predict(np.array(xtest_feature)))
# cat_exploration(subm, 'SalePrice')
#subm['SalePrice'] = np.expm1(subm[['SalePrice']])
subm.to_csv("E:/Data Mining/GroupCoursework/Data/Submission.csv", index=None)

# predict.to_csv('RandomForest-submission1.csv', index=None)

